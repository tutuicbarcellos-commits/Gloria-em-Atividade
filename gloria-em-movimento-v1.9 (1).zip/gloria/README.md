# Glória em Movimento

Guia digital local do bairro **Glória**, zona sul de **Porto Alegre (RS)** — comércios, serviços, mapa em tempo real e agora **conta de usuário real** (Supabase).

## Atualizações desta versão (v1.8)

- **Correções**: README alinhado com o Gemini (a função usa `GEMINI_API_KEY`); `theme_color` do manifest agora verde; service worker não guarda mais respostas de erro (404/500) no cache; header `Cross-Origin-Resource-Policy` removido (quebrava a prévia do link); sitemap sem âncoras `#`.
- **Segurança**: a Glória IA agora tem limite de uso por IP e só aceita chamadas do próprio site; `website` e `foto_url` só são usados se começarem com `http(s)://`.
- **Visual**: títulos em Bricolage Grotesque, topbar translúcida, fundo e cartões refinados, filtros em formato de pílula, foco visível mais forte.
- **Imagens**: logos reduzidos para o tamanho real de uso (de ~1,3 MB para uma fração).
- **Ainda pendente**: SRI nos scripts de CDN (precisa dos hashes, gerados com internet), páginas por comércio para SEO, minificação no deploy.

## Atualizações da versão anterior

- **Fotos dos comércios**: os cards agora usam a foto real do estabelecimento quando ela existe (`foto_url`, editável no painel admin ou na criação de um novo comércio) e, na falta dela, mostram uma ilustração da categoria (em vez do antigo placeholder de uma letra só) — funciona offline, sem depender de serviço externo.
- **Bug de layout ao rolar a página**: corrigido um erro de especificidade no CSS (`.only-mobile`/`.only-desktop`) que fazia o menu de desktop aparecer também no celular, estourando a largura da tela — causa raiz do layout "quebrando" ao rolar.
- **Visual**: cor principal trocada de azul para verde (`#22C55E`) e tema escuro refinado (fundo mais próximo do preto), removendo todo resquício da cor azul antiga do código.
- **Novidades desta rodada**: status real "Aberto agora"/"Fechado" (calculado a partir do horário, sem arriscar mostrar errado quando o texto é ambíguo), página de detalhes completa do estabelecimento (foto, avaliação, endereço, telefone, site, horário, descrição, favoritar, avaliar, compartilhar), compartilhamento via Web Share API (com cópia de link como alternativa), botão "Limpar filtros" nos estados vazios, página 404 personalizada, `netlify.toml`, e migração `supabase/migracao-website.sql` (rode-a se seu banco já existia antes desta atualização).
- **Glória IA**: assistente em linguagem natural ("✨ Pergunte à Glória"), com backend seguro via Netlify Function — ver seção 6.

## 0. Checklist contra o "prompt mestre" — o que está pronto e o que não está

**Feito e funcionando de verdade:** busca em tempo real com debounce, categorias clicáveis, cards com foto/nota/distância/status, mapa (Leaflet + OpenStreetMap — opção explicitamente permitida no prompt, sem custo e sem exigir API key), marcadores por categoria, geolocalização real com fallback amigável se negada, distância e ordenação por proximidade, página de detalhes do estabelecimento, horário real com "Aberto agora"/"Fechado", favoritos sincronizados por conta, histórico por conta, login e-mail/senha + recuperação de senha, perfil editável com foto (upload real), avaliações com nota+comentário (uma por usuário, editável), compartilhar, como chegar, painel admin básico, RLS completo, estados vazios/erro com ação, skeleton loading, responsividade auditada, SEO básico, PWA, dark mode, 404, `netlify.toml`.

**Não implementado — e por quê:**
- **URLs amigáveis por rota** (`/mapa`, `/favoritos`, `/estabelecimento/nome-do-local`): este projeto é HTML/CSS/JS estático, sem build nem framework de rotas. Implementar isso de verdade (com SEO funcionando, ou seja, cada página indexável separadamente) exigiria migrar para um framework com SSR/SSG (Next.js, Astro etc.) — uma reescrita de arquitetura, não um ajuste. Dá pra fazer, mas é uma decisão consciente que muda a stack inteira; não fiz por conta própria pra não arriscar quebrar o que já funciona.
- **Filtro de distância/raio e "mais populares"/"mais recentes" como filtros dedicados**: hoje a ordenação já cobre "mais próximos" e "melhor avaliados"; os demais foram deixados de fora nesta rodada por tempo, não por dificuldade — são incrementais.
- **Bottom sheet de filtros no mobile**: os filtros já existem (categoria, busca, ordenação) mas aparecem inline, não num modal deslizante. Incremental.
- **Autocomplete/sugestões de busca**: a busca já é instantânea (filtra a cada tecla, com debounce), mas não sugere termos enquanto digita.
- **Galeria de fotos por estabelecimento**: hoje é 1 foto por lugar (`foto_url`). Múltiplas fotos exigiriam uma tabela `business_images` à parte — o schema já tem RLS pronta pra outras tabelas, dá pra estender.

## 1. Backend real (Supabase) — status

Este projeto está conectado a um projeto Supabase real. Rode, nesta ordem, no SQL Editor:
1. `supabase/schema.sql` — tabelas, RLS e os 39 estabelecimentos reais do bairro.
2. `supabase/storage-e-admin.sql` — bucket de fotos de perfil e instruções para virar admin.

Com os dois rodados, o site já tem:

- **Login/cadastro com e-mail e senha**, sessão persistente entre visitas (`js/auth.js`). (Login com Google foi removido — ver nota abaixo.)
- **Perfil editável de verdade**: nome, telefone e **foto de perfil com upload real** (Supabase Storage, bucket `avatars`), com estatísticas reais (favoritos/avaliações vindas do banco).
- **Estabelecimentos vindos do banco de dados** (`js/app.js` → `carregarEstabelecimentos()`), não mais de uma lista fixa no código.
- **Favoritos sincronizados por conta**, funcionam em qualquer dispositivo em que a pessoa fizer login.
- **Avaliações reais** (1–5 estrelas + comentário), uma por usuário por estabelecimento, com média recalculada automaticamente.
- **Histórico real**: toda busca (2+ caracteres) e todo "Ver detalhes"/"Como chegar" clicado fica salvo por usuário, com tela pra ver e limpar (acessível pelo perfil → "Ver meu histórico").
- **Painel administrativo**: usuários com `role = 'admin'` veem um link "Painel admin" no menu, onde dá pra criar estabelecimentos e editar nome/categoria/endereço/telefone/horário/ativo dos existentes, direto pelo site.

**⚠️ Configuração pendente no painel do Supabase — verifique antes de testar:**
Por padrão, o Supabase exige **confirmação de e-mail** antes do primeiro login funcionar. Se um cadastro for feito e o login em seguida falhar com "E-mail ou senha incorretos" mesmo com a senha certa, é isso — vá em **Authentication → Sign In / Providers → Email** e desative "Confirm email" (bom para testar rápido) ou configure o envio de e-mail de confirmação (para produção).

**Login com Google:** removido a pedido — o site usa só e-mail/senha por enquanto. O Supabase Auth continua com a estrutura pronta pra reativar um login social (Google ou outro provedor) a qualquer momento, se decidir voltar atrás.

**Como virar admin:** veja o passo a passo no final de `supabase/storage-e-admin.sql` — resumindo, é um `update` no SQL Editor trocando o `role` do seu usuário para `'admin'`.

## 2. Segurança de verdade, sem exagero

Nenhuma senha passa pelo meu código: `auth.signInWithPassword`/`signUp` mandam a senha direto pro Supabase por HTTPS, que já faz o hash (bcrypt) e nunca a devolve. Todas as tabelas (`profiles`, `favoritos`, `avaliacoes`, `historico`, `estabelecimentos`) têm **Row Level Security**: o Postgres barra no nível da linha qualquer tentativa de um usuário ler/editar dado de outro, ou de alguém sem `role = 'admin'` mexer no catálogo — mesmo que a chamada de rede seja manipulada, a chave pública (`anon key`) não contorna isso. O bucket de fotos (`avatars`) segue a mesma lógica: cada usuário só escreve dentro da própria pasta (`<uid>/foto.ext`).

## 3. Dados dos comércios

Os ~39 estabelecimentos foram levantados via busca no Google Maps (nome, endereço, telefone, avaliação/horário reais) e estão populados como *seed* no `supabase/schema.sql` (rode esse arquivo uma vez no SQL Editor do seu projeto). A partir daí, o site sempre busca do banco — atualizar um estabelecimento é uma alteração no banco, não no código do site.

**Limitações que continuam existindo, mesmo com banco real:**
- Os dados de nome/endereço/telefone/horário são um retrato do momento da pesquisa — nada os atualiza sozinho se o comércio mudar de informação. Isso exigiria integração com a Google Places API (respeitando os Termos de Serviço do Google).
- `nota_google`/`avaliacoes_google` são os valores importados do Google (referência); `nota_media`/`total_avaliacoes_app` são as avaliações feitas dentro do próprio Glória em Movimento — são coisas diferentes, mostradas separadamente na view.
- **Fotos**: a coluna `foto_url` existe no banco, mas o *seed* não veio com fotos (eu não tinha como obter fotos reais e licenciadas dos 39 comércios). Adicione fotos aos poucos pelo painel admin (campo "Foto") ou direto no banco — até lá, cada card mostra uma ilustração da categoria no lugar da foto.

## 4. O que está implementado (front-end)

Responsividade mobile-first (alvos de toque ≥ 44px), PWA (manifest + service worker + cache offline), busca instantânea, filtro por categoria, geolocalização em tempo real com distância/ordenação, tema claro/escuro, SEO (meta tags, sitemap, robots.txt, schema.org, breadcrumbs), acessibilidade (WCAG), `_headers` com CSP/HSTS para o Netlify.

## 5. Estrutura de arquivos

```
gloria/
├── index.html
├── offline.html
├── 404.html
├── manifest.json
├── sw.js
├── _headers
├── netlify.toml
├── robots.txt
├── sitemap.xml
├── css/styles.css
├── js/
│   ├── app.js                # UI, mapa, busca, favoritos/avaliações/histórico/admin/detalhes
│   ├── auth.js                 # login (e-mail e senha), cadastro, sessão, perfil, upload de foto
│   ├── supabase-config.js      # URL + chave pública do projeto Supabase
│   └── ai-assistente.js        # front-end da Glória IA (chat, busca local, ações dos cards)
├── netlify/functions/
│   └── gloria-ia.js             # backend seguro da Glória IA (chama a API do Gemini; chave nunca vai pro navegador)
├── supabase/
│   ├── schema.sql               # tabelas, RLS e dados iniciais reais do bairro
│   ├── storage-e-admin.sql      # bucket de fotos + como virar admin
│   └── migracao-website.sql     # adiciona a coluna "website" (rode se seu banco já existia)
└── icons/
```

## 6. Glória IA — assistente do bairro

Assistente em linguagem natural ("✨ Pergunte à Glória", botão flutuante no canto da tela) que ajuda a achar comércios por conversa em vez de filtros manuais.

**Como funciona, em uma frase:** a mensagem da pessoa vai pra uma Netlify Function (`netlify/functions/gloria-ia.js`), que usa um modelo de IA só pra **entender a intenção** (categoria, se quer aberto agora, se precisa de localização...); quem busca, filtra e mostra os estabelecimentos de verdade é o próprio `js/ai-assistente.js`, usando os mesmos dados já carregados do Supabase (`ESTABELECIMENTOS`) que o resto do site usa. **A IA nunca vê nem inventa dado de estabelecimento** — ela não tem acesso a nomes, endereços, notas ou telefones, então não tem como alucinar isso.

**Configuração necessária no Netlify** (Site settings → Environment variables):
- `GEMINI_API_KEY` — **obrigatória**. Sem ela, a Glória IA responde com uma mensagem amigável de indisponibilidade em vez de quebrar.
- `GLORIA_IA_MODEL` — opcional, padrão `gemini-flash-latest` (rápido e barato, adequado pra uma tarefa de classificação). Chave grátis em aistudio.google.com/apikey.

Depois de configurar a variável, é só dar um novo deploy (ou "Clear cache and deploy") pra ela valer.

**O que a IA NÃO faz, de propósito (dado real que não existe no banco):**
- **Não filtra por preço/faixa de preço.** Não existe essa coluna em `estabelecimentos`. Se alguém pedir "barato", a Glória IA avisa que não tem esse dado em vez de chutar.
- **Não sabe sobre eventos/promoções.** Não existe tabela de eventos no schema atual. Perguntas assim recebem uma resposta explicando essa limitação.
- **Não substitui o mapa nem cria um segundo mapa.** O botão "Ver no mapa" dos cards centraliza e abre um popup no mesmo mapa Leaflet que já existe na página.

**Segurança:** a `GEMINI_API_KEY` fica só na Netlify Function (nunca no navegador). A função também não recebe nem usa a `service_role key` do Supabase — não toca no banco. Toda entrada é limitada em tamanho (mensagem, histórico) e a categoria devolvida pela IA é validada contra a lista real de categorias antes de ser usada, então uma resposta mal-formada da IA nunca vira uma busca inválida.

**Limitação conhecida (ok pro estágio atual, mas vale saber):** os dados dos estabelecimentos que a Netlify Function usa pra validar a lista de categorias vêm do próprio navegador da pessoa a cada request (a lista de categorias, não os estabelecimentos). Isso é seguro porque é informação pública (a mesma que já aparece na tela), mas se um dia quiser "engessar" isso 100% no servidor, dá pra mover a lista de categorias pra dentro da função também.

## 7. Antes de publicar

1. No painel do Supabase, revise as configurações de e-mail (seção 1 acima).
2. Se seu banco já existia antes desta versão, rode `supabase/migracao-website.sql` (adiciona a coluna `website`, usada na página de detalhes).
3. Troque o domínio de exemplo nas meta tags (OG/canonical/sitemap) pelo domínio real.
4. Rode uma auditoria [Lighthouse](https://developer.chrome.com/docs/lighthouse) no domínio final.
5. Configure `GEMINI_API_KEY` nas variáveis de ambiente do Netlify pra Glória IA funcionar (seção 6 acima) — sem ela o resto do site funciona normal, só a IA fica indisponível.
6. Próximos passos que ainda ficam de fora: URLs por rota (`/estabelecimento/nome`, ver seção 0), exclusão real de estabelecimento pelo painel admin (hoje é só ativar/desativar, de propósito), moderação de avaliações/denúncias, filtro de distância/raio, e paginação no painel admin se o catálogo crescer muito.
