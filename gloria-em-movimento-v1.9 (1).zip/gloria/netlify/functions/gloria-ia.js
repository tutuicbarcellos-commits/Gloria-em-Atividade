/* =============================================================
   Glória em Movimento — Glória IA (backend seguro)
   =============================================================
   O que esta função FAZ:
   - Recebe a mensagem do usuário (+ um resuminho da conversa) e usa
     um modelo de IA só para ENTENDER o que a pessoa quer (categoria,
     se quer só os abertos agora, se pediu proximidade, se são duas
     necessidades ao mesmo tempo, se está fora do escopo do site...).

   O que esta função NUNCA FAZ:
   - Ela não sabe nada sobre os estabelecimentos reais (nomes,
     endereços, notas, telefones...). Esses dados NUNCA são enviados
     pra IA e a IA NUNCA os inventa, porque ela simplesmente não os
     vê. Quem busca, filtra e mostra os estabelecimentos de verdade é
     o próprio site (js/ai-assistente.js), usando os mesmos dados já
     carregados do Supabase que o resto do app usa (ESTABELECIMENTOS).
     Isso elimina por completo o risco de a IA "alucinar" um
     comércio, endereço, telefone, horário, nota ou preço que não
     existe no banco.
   - Ela nunca recebe nem usa a service_role key do Supabase — não
     toca no banco de dado nenhum. Só a GEMINI_API_KEY (secreta)
     fica aqui no servidor; o navegador nunca tem acesso a ela.

   Variável de ambiente necessária (configurar no Netlify):
   - GEMINI_API_KEY (obrigatória — gere grátis em aistudio.google.com/apikey)
   - GLORIA_IA_MODEL (opcional — padrão: gemini-flash-latest)
   ============================================================= */

const MODELO_PADRAO = 'gemini-flash-latest';
const LIMITE_MENSAGEM = 400;
const LIMITE_HISTORICO = 6;
const LIMITE_TEXTO_HISTORICO = 240;

const RESPOSTA_INDISPONIVEL = {
  erro: true,
  resposta: 'Não consegui consultar a assistente agora. Tente novamente em alguns instantes.',
};

function montarSystemPrompt(categorias) {
  const listaCategorias = categorias.map((c) => `${c.id} (${c.label})`).join(', ');
  return `Você é a "Glória IA", a assistente oficial e exclusiva do site Glória em Movimento — um guia digital do bairro Glória, em Porto Alegre (RS).

Sua ÚNICA função nesta etapa é interpretar a mensagem da pessoa e devolver a intenção dela em JSON. Você NÃO tem acesso à lista de estabelecimentos — quem faz a busca de verdade é o próprio site, usando dados reais do banco de dados. Por isso:
- NUNCA invente ou cite nomes de estabelecimentos, endereços, telefones, notas, horários ou preços — você não tem essa informação e não deve fingir que tem.
- Sua tarefa é só classificar o pedido, não respondê-lo com dados.

Categorias que existem de verdade no site (use exatamente um destes ids, ou null se não identificar/não se aplicar): ${listaCategorias}.

IMPORTANTE sobre limitações reais do sistema (nunca finja que não existem):
- Não existe cadastro de preço/faixa de preço dos estabelecimentos. Se a pessoa pedir "barato", "em conta", "caro" etc., marque "pedidoPreco": true — o site vai avisar honestamente que esse dado não existe, em vez de inventar.
- Não existe cadastro de eventos. Se perguntarem sobre eventos/promoções, marque "foraDeEscopo": true e explique brevemente essa limitação na "resposta".
- Você não sabe a localização da pessoa nem calcula distância — isso é feito pelo site com GPS real. Só marque "precisaLocalizacao": true quando a pergunta depender de proximidade (“perto de mim”, “mais próximo” etc.) E a variável indicando localização disponível for falsa.

Responda SEMPRE e SOMENTE com um objeto JSON válido, sem markdown, sem texto antes ou depois, neste formato exato:
{
  "resposta": "frase curta, natural e simpática, no tom de quem conhece o bairro Glória — sem citar estabelecimentos específicos",
  "categorias": ["id1", "id2"] ou [],
  "termoBusca": "palavra-chave específica mencionada (ex.: nome de um lugar) ou null",
  "apenasAbertos": true ou false,
  "ordenarPor": "distancia" ou "avaliacao" ou null,
  "precisaLocalizacao": true ou false,
  "pedidoPreco": true ou false,
  "foraDeEscopo": true ou false
}

Se a pessoa pedir duas coisas em sequência (ex.: "um lanche e depois uma farmácia"), coloque as duas categorias em "categorias", na ordem pedida — o site vai mostrar um grupo de resultados para cada uma.
Se a pergunta for sobre algo completamente fora do bairro Glória ou do que o site oferece (clima, notícias, assuntos gerais, outras cidades), marque "foraDeEscopo": true e responda gentilmente que sua especialidade é ajudar a encontrar comércios e serviços do bairro Glória.
Nunca use gírias forçadas nem seja prolixa: 1 a 2 frases curtas em "resposta" é o ideal.`;
}

function extrairJSON(texto) {
  if (!texto) return null;
  const limpo = texto.trim().replace(/^```(json)?/i, '').replace(/```$/, '').trim();
  const inicio = limpo.indexOf('{');
  const fim = limpo.lastIndexOf('}');
  if (inicio === -1 || fim === -1 || fim < inicio) return null;
  try {
    return JSON.parse(limpo.slice(inicio, fim + 1));
  } catch {
    return null;
  }
}

function sanearSaida(json, categoriasValidas) {
  const idsValidos = new Set(categoriasValidas.map((c) => c.id));
  const categorias = Array.isArray(json?.categorias)
    ? json.categorias.filter((id) => idsValidos.has(id)).slice(0, 3)
    : [];
  return {
    resposta: typeof json?.resposta === 'string' && json.resposta.trim()
      ? json.resposta.trim().slice(0, 500)
      : 'Encontrei algumas opções para você.',
    categorias,
    termoBusca: typeof json?.termoBusca === 'string' && json.termoBusca.trim() ? json.termoBusca.trim().slice(0, 80) : null,
    apenasAbertos: json?.apenasAbertos === true,
    ordenarPor: ['distancia', 'avaliacao'].includes(json?.ordenarPor) ? json.ordenarPor : null,
    precisaLocalizacao: json?.precisaLocalizacao === true,
    pedidoPreco: json?.pedidoPreco === true,
    foraDeEscopo: json?.foraDeEscopo === true,
  };
}

// Limite simples por IP (em memória, por instância da função): protege a cota
// do Gemini contra uso abusivo. Para limite global, use um store externo.
const JANELA_MS = 10 * 60 * 1000;
const MAX_POR_JANELA = 20;
const acessos = new Map();
function excedeuLimite(ip) {
  const agora = Date.now();
  const lista = (acessos.get(ip) || []).filter((t) => agora - t < JANELA_MS);
  lista.push(agora);
  acessos.set(ip, lista);
  if (acessos.size > 5000) acessos.clear();
  return lista.length > MAX_POR_JANELA;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ erro: true, resposta: 'Método não permitido.' }) };
  }

  const origem = event.headers?.origin || event.headers?.Origin || '';
  const host = event.headers?.host || '';
  if (origem && host && !origem.endsWith('//' + host)) {
    return { statusCode: 403, body: JSON.stringify({ erro: true, resposta: 'Origem não permitida.' }) };
  }
  const ip = event.headers?.['x-nf-client-connection-ip'] || event.headers?.['x-forwarded-for'] || 'desconhecido';
  if (excedeuLimite(ip)) {
    return { statusCode: 429, body: JSON.stringify({ erro: true, resposta: 'Muitas perguntas em pouco tempo. Tente de novo em alguns minutos.' }) };
  }

  let corpo;
  try {
    corpo = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, body: JSON.stringify({ erro: true, resposta: 'Requisição inválida.' }) };
  }

  const mensagem = String(corpo.mensagem || '').trim().slice(0, LIMITE_MENSAGEM);
  if (!mensagem) {
    return { statusCode: 400, body: JSON.stringify({ erro: true, resposta: 'Digite uma pergunta para a Glória IA.' }) };
  }

  const categoriasValidas = Array.isArray(corpo.categorias)
    ? corpo.categorias.filter((c) => c && typeof c.id === 'string' && typeof c.label === 'string').slice(0, 20)
    : [];

  const historico = Array.isArray(corpo.historico)
    ? corpo.historico.slice(-LIMITE_HISTORICO).map((m) => ({
        role: m.papel === 'ia' ? 'assistant' : 'user',
        content: String(m.texto || '').slice(0, LIMITE_TEXTO_HISTORICO),
      }))
    : [];

  const temLocalizacao = corpo.temLocalizacao === true;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.error('GEMINI_API_KEY não configurada no ambiente do Netlify.');
    return { statusCode: 200, body: JSON.stringify(RESPOSTA_INDISPONIVEL) };
  }

  // Gemini usa role "model" em vez de "assistant" para o turno da IA.
  const mensagensGemini = [
    ...historico.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })),
    {
      role: 'user',
      parts: [{ text: `Localização do usuário disponível: ${temLocalizacao ? 'sim' : 'não'}.\nMensagem: ${mensagem}` }],
    },
  ];

  const modelo = process.env.GLORIA_IA_MODEL || MODELO_PADRAO;

  try {
    const resposta = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey,
        },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: montarSystemPrompt(categoriasValidas) }] },
          contents: mensagensGemini,
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 500,
            responseMimeType: 'application/json',
          },
        }),
      }
    );

    if (!resposta.ok) {
      console.error('Erro da API de IA:', resposta.status, await resposta.text());
      return { statusCode: 200, body: JSON.stringify(RESPOSTA_INDISPONIVEL) };
    }

    const dados = await resposta.json();
    const texto = dados?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
    const json = extrairJSON(texto);
    if (!json) {
      console.error('IA não devolveu JSON válido:', texto);
      return { statusCode: 200, body: JSON.stringify(RESPOSTA_INDISPONIVEL) };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ erro: false, ...sanearSaida(json, categoriasValidas) }),
    };
  } catch (err) {
    console.error('Falha ao consultar a Glória IA:', err);
    return { statusCode: 200, body: JSON.stringify(RESPOSTA_INDISPONIVEL) };
  }
};
